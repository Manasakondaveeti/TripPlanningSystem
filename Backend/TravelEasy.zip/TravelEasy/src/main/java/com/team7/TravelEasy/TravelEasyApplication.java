package com.team7.TravelEasy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelEasyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelEasyApplication.class, args);
	}

}
